# AgentOps for Securities — Evidence Bundle v5

## Purpose
This bundle preserves versioned project archives and validation evidence for the AgentOps for Securities research prototype. Earlier versions are retained unchanged; this bundle does not replace them.

## Contents
- `artifacts/`: all AgentOps for Securities ZIP artifacts present in the working delivery directory at bundle creation, including prior evidence bundles, source releases, phase snapshots, and the v5 source archive.
- `validation/TEST_EXECUTION_2026-11-20.txt`: actual v5 clean-room validation commands and results.
- `MANIFEST.json`: byte sizes and SHA-256 hashes for every artifact and validation file included in this bundle.

## Provenance
- v5 source archive was built from the previously prepared GitHub-ready v4 source archive.
- README and GitHub publication documentation were updated to reflect the actual repository state.
- Apache-2.0 LICENSE was added to the v5 source archive.
- MANIFEST.json inside v5 was regenerated for all 36 tracked files.
- v5 was freshly extracted and tested on 2026-11-20.
- Repository metadata and topic tags were applied to `https://github.com/davidwuphp-a11y/agentops-for-securities`.

## Evidence boundary / limitations
- The local v5 test results are not a hosted GitHub Actions result.
- The source archive has not yet been uploaded to GitHub; the repository currently contains its README, license, release notes, publication metadata, and archive-expansion workflow, but the full source tree is pending upload.
- No production deployment, real securities firm SOP, real customer data, live model-provider request, live financial decision, regulatory certification, independent penetration test, enterprise identity integration, or WORM audit storage is claimed.
- The benchmark contains synthetic deterministic data and its test split is not secret or blind.
- The credential scan checks only a limited set of common token patterns and is not a complete secret review.

## Retention rule
Do not delete or overwrite earlier versioned ZIPs. Add future versions as new artifacts and regenerate the outer manifest.
